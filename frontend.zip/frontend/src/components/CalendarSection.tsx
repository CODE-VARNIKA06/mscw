import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Clock, MapPin, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { societies } from '@/data/societies';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, isToday, parseISO, isValid } from 'date-fns';

interface CalendarEvent {
  id: string;
  societyId: string;
  societyName: string;
  title: string;
  date: Date;
  type: 'fest' | 'registration';
  colorAccent: string;
}

export const CalendarSection = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Generate events from societies data
  const events = useMemo<CalendarEvent[]>(() => {
    const eventList: CalendarEvent[] = [];
    
    societies.forEach(society => {
      // Add fest events
      if (society.fest?.date) {
        // Try to parse the date, handle various formats
        const dateStr = society.fest.date;
        let eventDate: Date | null = null;
        
        // Try different date formats
        if (dateStr.includes('2026')) {
          if (dateStr.includes('February 15')) {
            eventDate = new Date(2026, 1, 15);
          } else if (dateStr.includes('February')) {
            eventDate = new Date(2026, 1, 20);
          } else if (dateStr.includes('March')) {
            eventDate = new Date(2026, 2, 15);
          } else if (dateStr.includes('April')) {
            eventDate = new Date(2026, 3, 10);
          }
        }
        
        if (eventDate) {
          eventList.push({
            id: `${society.id}-fest`,
            societyId: society.id,
            societyName: society.name,
            title: society.fest.name,
            date: eventDate,
            type: 'fest',
            colorAccent: society.colorAccent
          });
        }
      }
      
      // Add registration opening events
      if (society.registrationStatus === 'soon' && society.registrationDate) {
        const dateStr = society.registrationDate;
        let eventDate: Date | null = null;
        
        if (dateStr.includes('January 20')) {
          eventDate = new Date(2026, 0, 20);
        } else if (dateStr.includes('January 25')) {
          eventDate = new Date(2026, 0, 25);
        }
        
        if (eventDate) {
          eventList.push({
            id: `${society.id}-reg`,
            societyId: society.id,
            societyName: society.name,
            title: `${society.name} Registrations Open`,
            date: eventDate,
            type: 'registration',
            colorAccent: society.colorAccent
          });
        }
      }
    });
    
    return eventList;
  }, []);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad the start of the calendar
  const startPadding = monthStart.getDay();
  const paddedDays = Array(startPadding).fill(null).concat(days);

  const getEventsForDay = (day: Date) => {
    return events.filter(event => isSameDay(event.date, day));
  };

  const upcomingEvents = useMemo(() => {
    const now = new Date();
    return events
      .filter(event => event.date >= now)
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .slice(0, 5);
  }, [events]);

  return (
    <section id="calendar" className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">Events</span> Calendar
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Never miss a fest, registration deadline, or event. Stay updated with all society activities.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2"
          >
            <div className="glass-card p-6 rounded-2xl">
              {/* Month Navigation */}
              <div className="flex items-center justify-between mb-6">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <h3 className="font-display text-xl font-bold">
                  {format(currentMonth, 'MMMM yyyy')}
                </h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              {/* Weekday Headers */}
              <div className="grid grid-cols-7 gap-2 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {paddedDays.map((day, index) => {
                  if (!day) {
                    return <div key={`empty-${index}`} className="aspect-square" />;
                  }

                  const dayEvents = getEventsForDay(day);
                  const hasEvents = dayEvents.length > 0;
                  const isCurrentDay = isToday(day);

                  return (
                    <motion.div
                      key={day.toISOString()}
                      whileHover={{ scale: hasEvents ? 1.05 : 1 }}
                      className={`aspect-square p-1.5 rounded-xl transition-all cursor-pointer ${
                        isCurrentDay 
                          ? 'bg-primary/20 ring-2 ring-primary' 
                          : hasEvents 
                            ? 'bg-secondary/50 hover:bg-secondary' 
                            : 'hover:bg-secondary/30'
                      }`}
                    >
                      <div className="h-full flex flex-col">
                        <span className={`text-sm font-medium ${
                          isCurrentDay ? 'text-primary' : 'text-foreground'
                        }`}>
                          {format(day, 'd')}
                        </span>
                        {hasEvents && (
                          <div className="flex-1 flex flex-wrap gap-0.5 mt-1">
                            {dayEvents.slice(0, 3).map((event, i) => (
                              <div
                                key={event.id}
                                className="w-1.5 h-1.5 rounded-full"
                                style={{ backgroundColor: `hsl(${event.colorAccent})` }}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>

          {/* Upcoming Events */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <div className="glass-card p-6 rounded-2xl h-full">
              <h3 className="font-display text-lg font-bold mb-4 flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-primary" />
                Upcoming Events
              </h3>

              <div className="space-y-4">
                {upcomingEvents.length > 0 ? (
                  upcomingEvents.map((event, index) => (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-xl bg-secondary/30 border-l-4 transition-all hover:bg-secondary/50"
                      style={{ borderLeftColor: `hsl(${event.colorAccent})` }}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-foreground mb-1">
                            {event.title}
                          </p>
                          <p className="text-sm text-muted-foreground mb-2">
                            {event.societyName}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            {format(event.date, 'MMM d, yyyy')}
                          </div>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          event.type === 'fest' 
                            ? 'bg-primary/20 text-primary' 
                            : 'bg-emerald-500/20 text-emerald-400'
                        }`}>
                          {event.type === 'fest' ? 'Fest' : 'Registration'}
                        </span>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <CalendarIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No upcoming events</p>
                  </div>
                )}
              </div>

              {upcomingEvents.length > 0 && (
                <Button
                  variant="outline"
                  className="w-full mt-4"
                >
                  View All Events
                </Button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
