import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

interface SocietyRegistrationFormProps {
  societyId: string;
  societyName: string;
  onSuccess: () => void;
}

export const SocietyRegistrationForm = ({ societyId, societyName, onSuccess }: SocietyRegistrationFormProps) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    department: '',
    year: '',
    reason: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/society_register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          society_id: societyId,
          user_id: 'guest_user', // Replace with actual user ID when auth is integrated
          form_data: formData
        })
      });

      if (response.ok) {
        toast({
          title: "Success!",
          description: `Your application for ${societyName} has been submitted.`,
        });
        onSuccess();
      } else {
        throw new Error('Failed to submit');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 py-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input 
            id="name" 
            required 
            value={formData.name}
            onChange={e => setFormData({...formData, name: e.target.value})}
            placeholder="John Doe" 
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">College Email</Label>
          <Input 
            id="email" 
            type="email" 
            required 
            value={formData.email}
            onChange={e => setFormData({...formData, email: e.target.value})}
            placeholder="name@gmail.com" 
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input 
            id="phone" 
            required 
            value={formData.phone}
            onChange={e => setFormData({...formData, phone: e.target.value})}
            placeholder="+91 1234567890" 
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="year">Year of Study</Label>
          <Input 
            id="year" 
            required 
            value={formData.year}
            onChange={e => setFormData({...formData, year: e.target.value})}
            placeholder="e.g. 2nd Year" 
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reason">Why do you want to join?</Label>
        <Textarea 
          id="reason" 
          required 
          value={formData.reason}
          onChange={e => setFormData({...formData, reason: e.target.value})}
          placeholder="Tell us about your interest..." 
          className="min-h-[100px]"
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Submitting...
          </>
        ) : 'Submit Application'}
      </Button>
    </form>
  );
};
