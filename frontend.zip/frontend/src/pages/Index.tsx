import { useState, useCallback, useEffect } from 'react';
import { ParticleBackground } from '@/components/ParticleBackground';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { SocietiesSection } from '@/components/SocietiesSection';
import { CalendarSection } from '@/components/CalendarSection';
import { FollowingSection } from '@/components/FollowingSection';
import { SearchModal } from '@/components/SearchModal';
import { Footer } from '@/components/Footer';
import { FloatingActions } from '@/components/FloatingActions';
import { SocietyModal } from '@/components/SocietyModal';
import { AuthModal } from '@/components/AuthModal';
import { societies } from '@/data/societies';

const Index = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [currentSection, setCurrentSection] = useState('home');
  const [selectedSocietyId, setSelectedSocietyId] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    } else {
      setShowAuthModal(true);
    }
  }, []);

  const selectedSociety = selectedSocietyId 
    ? societies.find(s => s.id === selectedSocietyId) || null 
    : null;

  const handleNavigate = useCallback((section: string) => {
    setCurrentSection(section);
    
    if (section === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(section);
      if (element) {
        const offset = 80;
        const elementPosition = element.getBoundingClientRect().top + window.scrollY;
        window.scrollTo({
          top: elementPosition - offset,
          behavior: 'smooth'
        });
      }
    }
  }, []);

  const handleSelectSociety = useCallback((societyId: string) => {
    setSelectedSocietyId(societyId);
  }, []);

  // Update current section based on scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'societies', 'calendar', 'following'];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections.reverse()) {
        const element = section === 'home' ? document.body : document.getElementById(section);
        if (element) {
          const top = section === 'home' ? 0 : element.offsetTop;
          if (scrollPosition >= top) {
            setCurrentSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <ParticleBackground />
      
      <Navbar 
        onOpenSearch={() => setIsSearchOpen(true)}
        onNavigate={handleNavigate}
        currentSection={currentSection}
      />
      
      <main>
        <HeroSection onNavigate={handleNavigate} />
        <SocietiesSection />
        <CalendarSection />
        <FollowingSection />
      </main>

      <Footer />
      
      <FloatingActions onNavigate={handleNavigate} />
      
      <SearchModal 
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectSociety={handleSelectSociety}
      />

      <SocietyModal
        society={selectedSociety}
        isOpen={!!selectedSociety}
        onClose={() => setSelectedSocietyId(null)}
      />

      <AuthModal 
        isOpen={showAuthModal} 
        onSuccess={(userData) => {
          setUser(userData);
          setShowAuthModal(false);
        }} 
      />
    </div>
  );
};

export default Index;
