import { useState, useEffect, useCallback } from 'react';

const STORAGE_KEY = 'mscw_following_societies';

export const useFollowing = () => {
  const [following, setFollowing] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setFollowing(JSON.parse(stored));
      } catch {
        setFollowing([]);
      }
    }
  }, []);

  const toggleFollow = useCallback((societyId: string) => {
    setFollowing(prev => {
      const newFollowing = prev.includes(societyId)
        ? prev.filter(id => id !== societyId)
        : [...prev, societyId];
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newFollowing));
      return newFollowing;
    });
  }, []);

  const isFollowing = useCallback((societyId: string) => {
    return following.includes(societyId);
  }, [following]);

  return {
    following,
    toggleFollow,
    isFollowing,
    followingCount: following.length
  };
};
